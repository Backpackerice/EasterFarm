﻿namespace EasterFarm.GameLogic.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
