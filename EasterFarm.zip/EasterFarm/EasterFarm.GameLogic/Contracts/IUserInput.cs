﻿namespace EasterFarm.GameLogic.Contracts
{
    public interface IUserInput
    {
        void ProcessInput();
    }
}
