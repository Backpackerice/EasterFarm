﻿namespace EasterFarm.Models.Presents
{
    public enum PresentType
    {
        Kozunak = 20,
        ChocoEgg = 23,
        Cookie = 10,
        ChocoRabbit = 25,
        RabbitWithRibbon = 30
    }
}
