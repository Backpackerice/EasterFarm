﻿namespace EasterFarm.Models.MarketPlace
{

    public enum CurrencyType
    {
        Blueberry,
        Raspberry,
        //Milk,
        //Egg
    }
}
