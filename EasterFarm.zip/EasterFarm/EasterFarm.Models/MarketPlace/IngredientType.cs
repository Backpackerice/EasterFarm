﻿namespace EasterFarm.Models.MarketPlace
{
    public enum IngredientType
    {
        Flour = 2,
        Cocoa = 4,
        Ribbon = 5,
        Basket = 6,
        Rabbit = 8,
    }
}
