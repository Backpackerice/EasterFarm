﻿namespace EasterFarm.Models.MarketPlace
{
    public enum Category
    {
        Ingredient,
    }
}
