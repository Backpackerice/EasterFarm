﻿namespace EasterFarm.Models.FarmObjects.Byproducts
{
    public enum ByproductColor
    {
        None,
        Red,
        Blue,
    }
}