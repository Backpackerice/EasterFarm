﻿namespace EasterFarm.Models.FarmObjects.Byproducts
{
    public enum ByproductType
    {
        PlainEgg,
        EasterEgg,
        TrophyEgg,
        Milk,
    }
}
