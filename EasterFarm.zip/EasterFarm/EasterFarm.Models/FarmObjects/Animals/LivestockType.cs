﻿namespace EasterFarm.Models.MarketPlace
{
    public enum LivestockType
    {
        Hen = 15,
        Rabbit = 20,
        Lamb = 50
    }
}
