﻿namespace EasterFarm.Models.FarmObjects.Animals
{
    public class Fox : Villain
    {
        public Fox(MatrixCoords topLeft) 
            : base(topLeft)
        {
        }
    }
}
