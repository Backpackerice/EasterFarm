﻿namespace EasterFarm.Models.FarmObjects.Animals
{
    public class Wolf : Villain
    {
        public Wolf(MatrixCoords topLeft) 
            : base(topLeft)
        {
        }
    }
}
