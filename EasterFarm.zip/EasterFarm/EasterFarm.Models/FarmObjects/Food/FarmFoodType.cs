﻿namespace EasterFarm.Models.FarmObjects.Food
{
    public enum FarmFoodType
    {
        Blueberry,
        Raspberry
    }
}
