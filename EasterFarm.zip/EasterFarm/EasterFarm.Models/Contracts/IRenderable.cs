﻿namespace EasterFarm.Models.Contracts
{
    public interface IRenderable
    {
        MatrixCoords TopLeft { get; }
    }
}
