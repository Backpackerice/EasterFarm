﻿namespace EasterFarm.Models.Contracts
{
    public interface IMovable
    {
        void Move(int[,] map);
    }
}
