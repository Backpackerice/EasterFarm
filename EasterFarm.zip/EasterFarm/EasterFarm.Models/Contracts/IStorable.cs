﻿namespace EasterFarm.Models.Contracts
{
    using System;

    public interface IStorable
    {
        Enum Type { get; }
    }
}
