﻿namespace EasterFarm.Models.Contracts
{
    public interface IBuyable : ITradeable
    {
    }
}
