﻿namespace EasterFarm.Models.Contracts
{
    public interface ISellable : ITradeable
    {
    }
}
