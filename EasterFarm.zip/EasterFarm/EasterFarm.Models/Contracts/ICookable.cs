﻿namespace EasterFarm.Models.Contracts
{
    using System;

    public interface ICookable
    {
        Enum Type { get; }
    }
}
